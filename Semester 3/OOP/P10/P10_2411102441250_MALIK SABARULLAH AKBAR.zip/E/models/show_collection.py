class ShowCollection:
    def show_collection(self):
        for car in self.car_collection:
            print(car.show_info()) 
     